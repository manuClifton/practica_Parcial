
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int menu(void);
int orderMenu(void);
